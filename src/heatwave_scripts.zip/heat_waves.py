import os
import pandas as pd
import geopandas as gpd
import numpy as np
from DataAnalyst_v4.heat import Heat

data_dir = r"../data/interim/daily_temperature"

############################################################################################################
#### Determining extreme heat exposure
############################################################################################################

gambia_neighborhoods = Heat(
    os.path.join(data_dir, "Gambia", "modis_gambia_neighborhoods.csv")
)
gambia_neighborhoods.getData()

df = gambia_neighborhoods.heatwave()
df[df["consecutive_hot_days"] >= 3].groupby(by=["name", "block"]).agg(
    {"consecutive_hot_days": "first"}
)

gambia_women = pd.read_csv(
    os.path.join("outputs/anc_structured/Gambia", "Gambia_daily_gestation_location.csv")
)
gambia_women["exposure_date"] = pd.to_datetime(
    gambia_women["exposure_date"], format="%d/%m/%Y"
)
gambia_women

analysis_df = pd.merge(
    gambia_women,
    df,
    on=["neighborhood_code", "exposure_date"],
    how="left",
    validate="m:1",
)
analysis_df.drop(columns="facility_code")
